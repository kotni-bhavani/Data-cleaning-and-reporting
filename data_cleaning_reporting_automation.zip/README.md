# Data Cleaning & Reporting Automation

Power BI and Python project for automated data cleaning and reporting.
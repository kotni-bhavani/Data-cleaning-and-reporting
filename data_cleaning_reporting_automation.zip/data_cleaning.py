import pandas as pd
df=pd.read_csv('raw_data.csv')
df=df.drop_duplicates()
df['CustomerID']=df['CustomerID'].fillna(0)
df['Name']=df['Name'].fillna('Unknown')
df['Sales']=df['Sales'].fillna(df['Sales'].mean())
df.to_csv('cleaned_data.csv',index=False)
print('Done')
